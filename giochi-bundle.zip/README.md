# 🎮 I 4 Giochi Gemelli — Impara Giocando

Quattro moduli Next 15 (App Router + Tailwind + framer-motion) per la fascia 5-7 anni.

```
giochi/
├── pianeta-pongo/    🌍 Geografia — esplora i continenti, riconosci animali
├── laboratorio/      🧪 Chimica — combina atomi, scopri molecole
├── geometria/        📐 Geometria — costruisci forme, scopri Pitagora
└── fisica/           ⚙️ Fisica — catene causali, macchine Rube Goldberg
```

## La grammatica condivisa

Tutti e quattro insegnano lo **stesso meta-pattern** declinato in materie diverse:

> Mattoncini con identità + Regole di combinazione + Soglia di stabilità → Emergenza

Il bambino non lo sa, ma giocando ai quattro **costruisce lo stesso schema mentale quattro volte** — una volta su animali, una su atomi, una su forme, una su cause. Quando a scuola incontrerà chimica, geometria, fisica, geografia, riconoscerà il pattern. È questo il valore vero: non insegnare ricette, ma insegnare il *modo di pensare*.

| Gioco | Mattoncino (Δ) | Regola (⇄) | Soglia (P3) | Emergenza |
|---|---|---|---|---|
| Pongo | Continente | Animale↔habitat | Missione completata | Stella scoperta |
| Laboratorio | Atomo (manine) | Manine→coppie | Tutte occupate | Molecola |
| Geometria | Segmento (3/4/5) | Estremità→vertici | Ciclo chiuso | Figura |
| Fisica | Pezzo causale | Output→input compatibili | Catena START→FINISH | Macchina funziona |

## Installazione

```bash
# Da dentro la tua app Next 15
cp -r pianeta-pongo laboratorio geometria fisica app/giochi/

# Dipendenze (se non già presenti)
npm i framer-motion
```

Aggiungi nella home dell'app i 4 nuovi bottoni:

```tsx
{ emoji: '🌍', title: 'Pongo',        subtitle: 'Esplora il mondo',         href: '/giochi/pianeta-pongo' }
{ emoji: '🧪', title: 'Laboratorio',  subtitle: 'Combina gli atomi',        href: '/giochi/laboratorio' }
{ emoji: '📐', title: 'Geometria',    subtitle: 'Costruisci le forme',      href: '/giochi/geometria' }
{ emoji: '⚙️', title: 'La Macchina',  subtitle: 'Catene di reazioni',       href: '/giochi/fisica' }
```

## Refactor consigliato dopo il deploy

Tre file sono **duplicati identici** in `laboratorio`, `geometria`, `fisica`:

- `_hooks/useDrag.ts`
- `_lib/composition.ts`

Quando avrai testato e tutto gira, conviene spostarli in `app/_shared/` e importare da lì:

```
app/
├── _shared/
│   ├── useDrag.ts
│   └── composition.ts
├── giochi/
│   ├── pianeta-pongo/  (usa _hooks/useDragDrop.ts proprio, leggermente diverso — si può unificare)
│   ├── laboratorio/
│   ├── geometria/
│   └── fisica/
```

Risparmio: ~10% di codice, ma soprattutto **una sola fonte di verità** per evolverli insieme.

Altri componenti astraibili in `_shared/ui/`:
- `DiscoveryPopup` (molto simile in laboratorio, geometria, fisica)
- `CollectionPanel` (idem)
- `StatusBadge` (idem)

## Identità visiva

Ogni gioco ha un colore di sfondo distintivo (gradient radial) per riconoscibilità immediata:

- **Pongo**: azzurro cielo→blu oceano
- **Laboratorio**: giallo→arancione (laboratorio, caldo)
- **Geometria**: viola lavanda (matematico, calmo)
- **Fisica**: rosa→fucsia (energico, vivace)

Stessi pattern di interazione (palette in basso, header con stelle, popup di scoperta) per **coerenza percettiva**.

## Punti delicati comuni

- **Distanze di snap/hit** sono tarate a sentimento per dito adulto. Per bambini di 5 anni con dito piccolo, alzare ~20% (vedere ogni README del singolo gioco).
- **Niente audio**: scelta volontaria, dispositivi spesso in muto. I "versi", "suoni", "successi" sono feedback visivi/animati.
- **Niente penalizzazioni**: nessun gioco ha "errore" o "game over". Sbagliare = il pezzo torna indietro, lo stato non cambia. Si riprova all'infinito.
- **Niente timer**: i bambini possono fissare lo schermo 2-3 minuti per capire. Nessuna pressione temporale.

## Roadmap dopo il deploy

**Modalità Sfida** (per tutti e quattro): obiettivi specifici che costringono a pensare.

**Esagono come ponte**: nel Laboratorio mostro il favo d'ape → in Geometria scopro l'esagono e vedo che esiste anche come molecola di carbonio. *Cross-reference esplicito*.

**Modalità "racconta"**: per i 7enni che già leggono bene, ogni scoperta diventa una frasetta da decifrare. Sinergia con il gioco "Scrivi!" già nell'app.

**Quinto gioco — Biologia**: cellule che si combinano in organi che si combinano in organismi. Stessa grammatica, scala diversa. EAR P4 puro (scaling). Lo facciamo quando questi 4 sono stabili.

---

**Buon montaggio!** 🚀
